/**
 * $Id: ProcessKilledException.cs 153 2009-05-26 12:52:34Z eboeg $ 
 * 
 * This file is part of the Process Language Runtime (PLR) 
 * and is licensed under the GPL v3.0.
 * 
 * Author: Einar Egilsson (einar@einaregilsson.com) 
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace PLR.Runtime {
    public class ProcessKilledException : Exception{
    }
}
