﻿/**
 * $Id: IAnalysis.cs 183 2009-06-09 13:06:37Z eboeg $ 
 * 
 * This file is part of the Process Language Runtime (PLR) 
 * and is licensed under the GPL v3.0.
 * 
 * Author: Einar Egilsson (einar@einaregilsson.com) 
 */
using System;
using System.Collections.Generic;
using System.Text;
using PLR.AST;

namespace PLR.Analysis {
    public interface IAnalysis {
        List<Warning> Analyze(ProcessSystem system);
    }
}
